# Goldhen

the goldhen.bin is from https://github.com/GoldHEN/GoldHEN/releases
